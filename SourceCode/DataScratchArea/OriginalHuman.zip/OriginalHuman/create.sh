#cd ~/GitMahost/Anatomy/Database/Tasks/CreateHuman009/SQLFiles/EmptyHuman/
echo 'create database humanOriginal;' | mysql -uroot 
