#cd ~/GitMahost/Anatomy/Database/Tasks/CreateHuman009/SQLFiles/EmptyHuman/
mysql -uroot humanOriginal < insert.sql
