#cd ~/GitMahost/Anatomy/Database/Tasks/CreateHuman009/SQLFiles/EmptyHuman/
echo 'drop database humanOriginal; create database humanOriginal;' | mysql -uroot humanOriginal
mysql -uroot humanOriginal < yiyas_human_anatomy_dump.sql
